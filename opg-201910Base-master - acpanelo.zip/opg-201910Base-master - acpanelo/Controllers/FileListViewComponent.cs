﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;
using Newtonsoft.Json;
using opg_201910_interview.Models;

namespace opg_201910_interview.Controllers
{
    public class FileListViewComponent : ViewComponent
    {
        private readonly IWebHostEnvironment _env;
        
        private ClientRecord clientRecord;
        string contentRootPath;

        public FileListViewComponent(IWebHostEnvironment env)
        {
            _env = env;
            contentRootPath = env.ContentRootPath;
        }

        public IViewComponentResult Invoke(int clientId)
        {
            string content = String.Empty;
            var modelObject = new FileList();
            try
            {
                this.clientRecord = GetClientRecord(clientId.ToString());
                if (this.clientRecord != null)
                {
                    this.clientRecord.FileDirectoryPath = Path.Combine(contentRootPath, this.clientRecord.FileDirectoryPath);
                    modelObject.ClientName = this.clientRecord.ClientName;

                    List<ClientFile> clientFiles = GetClientFiles();
                    modelObject.Filenames = (from a in clientFiles
                                             select a.Filename).ToList().ToArray();

                    content = JsonConvert.SerializeObject(modelObject, Formatting.Indented);
                }
                else
                {
                    content = "Invalid URL and/or Client ID.";
                }
            }
            catch
            {
                content = "An error has occured while processing the request.";
            }
            return new ContentViewComponentResult(content);
        }

        private ClientRecord GetClientRecord(string clientId)
        {
            var clients = this.HttpContext.Session.GetObject<List<ClientRecord>>("clients");

            ClientRecord client = clients.Find(c => c.ClientId == clientId);
            return client;
        }

        private List<ClientFile> GetClientFiles()
        {
            List<ClientFile> ClientFiles = new List<ClientFile>();

            ClientFiles.AddRange(ClientBL.GetFileList(this.clientRecord));

            return ClientFiles;
        }


        
    }
}
