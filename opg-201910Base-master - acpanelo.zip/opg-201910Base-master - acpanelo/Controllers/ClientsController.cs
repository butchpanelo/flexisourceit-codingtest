﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using opg_201910_interview.Models;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.Eventing.Reader;
using Newtonsoft.Json;

namespace opg_201910_interview.Controllers
{
    [Route("[controller]")]
    public class ClientsController : Controller
    {

        private readonly ILogger<ClientsController> _logger;
        
        private List<ClientRecord> _clients;

        public ClientsController(ILogger<ClientsController> logger, IConfiguration config)
        {
            _logger = logger;

            _clients = ClientConfig.GetClients(config);

           
        }

        [Route("")]
        [Route("{id}")]
        public IActionResult Index(int? id)
        {
            var Model = new ClientsModel();
            var ClientList = GetClientListWithPrompt();

            Model.SelectedId = id;
            Model.ClientList = ClientList; ;

            this.HttpContext.Session.SetObject("clients", _clients);

            return View(Model);
        }

        private List<Client> GetClientListWithPrompt()
        {
            List<Client> ClientList = new List<Client>();
            
            ClientList.Add(new Client { ClientId = "0", ClientName = "-- Select Client --" });
            ClientList.AddRange(ClientBL.GetClientList(_clients));

            

            return ClientList;
        }
    }
}
