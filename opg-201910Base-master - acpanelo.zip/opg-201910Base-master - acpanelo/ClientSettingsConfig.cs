﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace opg_201910_interview
{
    public class ClientRecord
    {
        public string ClientId { get; set; }
        public string ClientName { get; set; }
        public string FileDirectoryPath { get; set; }
        public string FileOrder { get; set; }
        public string FileDatePattern { get; set; }
    }

    public static class ClientConfig
    {
        public static List<ClientRecord> GetClients(IConfiguration Configuration)
        {
            return Configuration.GetSection("ClientSettings:Clients").Get<List<ClientRecord>>();
        }
    }
}
