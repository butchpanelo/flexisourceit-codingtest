﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace opg_201910_interview.Models
{
    public class ClientsModel
    {
        public int? SelectedId = null;
        public List<Client> ClientList;
    }

    public class Client : ClientRecord
    {
        public bool Selected { get; set; }
    }

    public class ClientFile
    {
        public string Filename { get; set; }
        public string DateUploaded { get; set; }
    }

    public class FileList
    {
        public string ClientName { get; set; }
        public string[] Filenames { get; set; }
    }


}