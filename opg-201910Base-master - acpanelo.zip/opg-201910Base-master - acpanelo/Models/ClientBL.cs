﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace opg_201910_interview.Models
{
    public class ClientBL
    {
        public static List<Client> GetClientList(List<ClientRecord> clients)
        {
            List<Client> ClientList = new List<Client>();

            clients.ForEach(c =>
            {
                ClientList.Add(new Client { ClientId = c.ClientId, ClientName = c.ClientName });
            });

            return ClientList;
        }

        public static List<ClientFile> GetFileList(string clientId, string filepath)
        {
            List<ClientFile> FileList = new List<ClientFile>();

            string[] filenames = Directory.GetFiles(filepath);
            filenames.ToList().ForEach(f =>
            {
                FileInfo fi = new FileInfo(f);
                FileList.Add(new ClientFile { Filename = fi.Name, DateUploaded = fi.CreationTime.ToString() });
            });

            return FileList;
        }

        public static List<ClientFile> GetFileList(ClientRecord clientRecord)
        {
            List<ClientFile> FileList = new List<ClientFile>();

            string filepath = clientRecord.FileDirectoryPath;
            string[] fileorder = clientRecord.FileOrder.Split(",");

            List<string> filenames = new List<string>();

            Regex re = new Regex(clientRecord.FileDatePattern);
            Directory.GetFiles(filepath).ToList().ForEach(f =>
            {
                FileInfo fi = new FileInfo(f);
                if (re.IsMatch(fi.Name))
                {
                    filenames.Add(fi.Name);
                }


            });


            fileorder.ToList().ForEach(p =>
            {
                filenames.ForEach(f =>
                {
                FileInfo fi = new FileInfo(f);
                    if (fi.Name.StartsWith(p, StringComparison.OrdinalIgnoreCase))
                    {
                        FileList.Add(new ClientFile { Filename = fi.Name, DateUploaded = fi.CreationTime.ToString() });
                    }
                });
            });
           
             return FileList;     
        } 
        
    }
}
